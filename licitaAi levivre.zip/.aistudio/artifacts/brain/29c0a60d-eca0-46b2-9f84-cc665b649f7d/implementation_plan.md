# LicitaAI Engine — Co-piloto de Licitações & Vendas Governamentais (Especializado para Levivre Viagens)

O **LicitaAI Engine** é uma plataforma e co-piloto de inteligência jurídica e operacional especializada no ciclo completo de vendas públicas (B2G) sob a **Nova Lei de Licitações e Contratos Administrativos (Lei nº 14.133/2021)** e a **LC 123/2006**, desenhada com regras de negócio e parâmetros específicos para a **Levivre Viagens** (agência de turismo com escopo em passagens aéreas nacionais e internacionais, hospedagens, cruzeiros, intercâmbio, assessoria de passaportes e vistos, e agenciamento de viagens corporativas para o setor público).

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Decisão de Segmentação de Negócio Confirmada**: O sistema será customizado sob medida para o perfil da **Levivre Viagens** — incorporando no analisador de editais e no gerador de minutas os padrões específicos de agenciamento de viagens públicas (ex.: taxa de agenciamento DU/RAV fixa ou percentual, repasse de taxas de embarque, reservas hoteleiras, emissão e remarcação, habilitação com **CADASTUR** e IATA, atestados de capacidade técnica de agenciamento, e ferramentas OBT/GDS).

- **Perfil Confirmado**: Agência de Turismo & Gestão de Viagens Corporativas/Governamentais (**Levivre Viagens**).
- **Entrada de Editais**: Upload de arquivos (PDF e TXT) + Colagem direta de texto + Editais reais pré-carregados de órgãos públicos (ex.: Pregão de Agenciamento de Viagens da Câmara Municipal, Dispensa Eletrônica de Hospedagem de Universidade Federal, Pregão de Emissão de Passagens e Vistos de Tribunal) para testes imediatos.
- **Backend de IA Server-Side**: Integração via `@google/genai` com `gemini-3.8-flash` no backend Express/Vite, garantindo respostas rápidas, fundamentação jurídica estrita na Lei 14.133/2021 e segurança de chaves.

---

## 1. Overview & Core Concept

### O que o LicitaAI Engine faz:
1. **Análise Executiva & Diagnóstico de Editais**:
   - Extrai instantaneamente: Objeto, Modalidade (Pregão, Concorrência, Dispensa Art. 75), Critério de Julgamento (Maior Desconto sobre a tabela oficial ou Menor Preço de Taxa de Agenciamento).
   - Mapeia exigências de Habilitação (Jurídica, Fiscal, Trabalhista, Qualificação Econômico-Financeira e Qualificação Técnica específica como CADASTUR e atestados).
   - Gera a **Matriz de Alertas de Risco**: aponta cláusulas potencialmente ilegais ou restritivas (ex.: exigência indevida de escritório físico no município da licitação, índices contábeis desproporcionais, retenção abusiva de pagamento) com base na jurisprudência do TCU e Lei 14.133/2021.
2. **Elaboração Automatizada de Peças Jurídicas & Administrativas**:
   - Redige minutas completas, fundamentadas e prontas para protocolo, com campos editáveis em colchetes `[EXEMPLO]`:
     - **Impugnações de Edital**: combatendo direcionamentos e exigências excessivas.
     - **Pedidos de Esclarecimento**: dúvidas sobre regras de cancelamento, reembolso, bagagem e cálculo da taxa.
     - **Recursos Administrativos e Contrarrazões**: para reverter inabilitações ou desclassificações arbitrárias.
     - **Declarações Obrigatórias em 1-clique**: ME/EPP (LC 123/2006), inexistência de fatos impeditivos, cumprimento dos requisitos de habilitação, reserva de vagas legais.
     - **Propostas Comerciais Personalizadas**: com estrutura de taxa de agenciamento, repasse de taxas aeroportuárias e validade.
3. **Módulo de Dispensa Eletrônica & Compra Direta (Art. 75)**:
   - Resposta ágil a dispensas eletrônicas para fornecimento urgente de bilhetes, diárias ou vistos para delegações e servidores públicos.
4. **Guia Prático de Credenciamento & Certidões**:
   - Checklist dos 6 níveis do **SICAF** (Cadastramento, Habilitação Jurídica, Regularidade Fiscal e Trabalhista, Regularidade Estadual/Municipal, Qualificação Técnica, Qualificação Econômico-Financeira).
   - Links oficiais diretos e orientações para emissão de certidões (CND Federal/PGFN, CNDT do TST, CRF do FGTS, Falência e Concordata, CADASTUR).
   - Monitor de validade de certidões da Levivre Viagens com alertas visuais preventivos.
5. **Chat Especialista Co-piloto LicitaAI**:
   - Co-piloto para tirar dúvidas em tempo real de interpretação da Lei 14.133/2021, jurisprudência do Tribunal de Contas da União (TCU) e estratégias de disputa na fase de lances.

---

## 2. User Experience & Visual Design

### A. Diretrizes Estéticas & Anti-Slop (Conforme `frontend-design` & `saas-dashboard`):
- **Identidade Visual**: Enterprise GovTech refinada, inspirada em plataformas de legaltech e inteligência pública.
- **Paleta de Cores (60-30-10)**:
  - Fundo Canvas (60%): Slate neutro ultra-limpo (`bg-slate-50` / modo noturno corporativo `bg-slate-950`).
  - Superfícies Estruturais (30%): Cartões com bordas sutis hairline de 1px (`border-slate-200` / `border-slate-800`), sem cartões aninhados dentro de cartões.
  - Acentos (10%): Azul Marinho Profundo Governamental (`#0B2545` e `#134074`) com acentos em Âmbar Jurídico (`#D97706`) e Esmeralda de Conformidade (`#059669`).
- **Tipografia**:
  - Títulos e Navegação: `Plus Jakarta Sans` para modernidade e clareza estrutural.
  - Métricas e Dados Tabulares: `JetBrains Mono` com `font-variant-numeric: tabular-nums` para prazos, valores, CNPJs e datas de sessão.
- **Top Bar Contract**:
  - Zona 1: Wordmark "LicitaAI Engine" com indicação sutil "Levivre Viagens".
  - Zona 2: Links de navegação unilineares sem quebra (`Analisador de Edital`, `Gerador de Peças`, `Dispensas Art. 75`, `SICAF & Certidões`, `Co-piloto Chat`).
  - Zona 3: Botão de ação rápida (`Novo Edital`).
- **Zero-Pill Discipline**:
  - Metadados sem cápsulas ou pílulas coloridas estáticas. Uso de texto puro com separadores tipográficos elegantes (`·`, `/`).
  - Abas interativas estilizadas como botões segmentados limpos.

---

## 3. Key Product Decisions & Trade-Offs

| Decisão de Arquitetura | Abordagem Escolhida | Racional & Vantagem | Alternativas Consideradas |
|---|---|---|---|
| **Motor de IA & Lei 14.133** | Server-side Gemini API (`gemini-3.8-flash`) com prompt jurídico especializado para agenciamento de viagens | Respostas com fundamentação jurídica sólida (artigos exatos da Lei 14.133/2021 e LC 123/2006), sem alucinação e com velocidade (< 3s). | Chamada client-side (insegura e proibida) ou modelos genéricos desprovidos de contexto da NLLC. |
| **Persistência de Dados** | Estado reativo no navegador (localStorage) com sincronização imediata | Permite salvar análises, minutas geradas e cadastro da Levivre Viagens sem depender de autenticação externa para uso instantâneo e offline. | Banco de dados remoto obrigatório logo no primeiro acesso (criaria fricção desnecessária). |
| **Biblioteca de Editais Exemplo** | 3 Editais reais e completos do setor de viagens públicas pré-carregados | Permite que o operador da Levivre Viagens explore imediatamente a análise de risco, matriz executiva e impugnações sem precisar buscar um arquivo externo na primeira visita. | Exigir obrigatoriamente upload manual de arquivo logo de início. |
| **Exportação de Minutas** | Visualizador rico com cópia em 1-clique, download em `.docx`/`.txt` e visualização de impressão A4 | Advogados e licitantes precisam enviar as peças rapidamente ao portal Compras.gov.br ou protocolar via e-mail/SEI. | Apenas texto simples em modal não editável. |

---

## 4. Technical Architecture & Data Strategy

### Diagrama de Arquitetura do Sistema

```
┌────────────────────────────────────────────────────────────────────────┐
│                   INTERFACE WEB CLIENT-SIDE (React 19)                 │
├────────────────────────────────────────────────────────────────────────┤
│  Top Navigation (Top Bar Contract: Brand · 5 Nav Links · Ação Rápida)   │
├──────────────────────────┬─────────────────────────┬───────────────────┤
│  Módulo de Análise       │  Gerador de Peças       │  Radar Dispensas  │
│  - Upload PDF/TXT        │  - Impugnação Lei 14133 │  - Art. 75 NLLC   │
│  - Extrator de Objeto    │  - Pedido Esclarecimento│  - Cotação rápida │
│  - Matriz Riscos/Alertas │  - Recursos / Contrarraz│  - Proposta OBT   │
│  - Requisitos Habilitação│  - Declarações 1-clique │  - Prazos lances  │
├──────────────────────────┴─────────────────────────┴───────────────────┤
│  SICAF & Certidões Manager (Checklist 6 Níveis, Validador & Links)     │
│  Co-piloto Chat Jurídico (Chat stream com contexto Levivre Viagens)   │
└─────────────────────────────────┬──────────────────────────────────────┘
                                  │ Requisições REST JSON
                                  ▼
┌────────────────────────────────────────────────────────────────────────┐
│               BACKEND SERVER-SIDE PROXY (Vite/Express Server)          │
├────────────────────────────────────────────────────────────────────────┤
│  Endpoints:                                                            │
│  • POST /api/analyze-edital       (Extrai matriz, riscos, habilitação) │
│  • POST /api/draft-document       (Redige peças jurídicas fundamentadas)│
│  • POST /api/quick-quote          (Calcula propostas de dispensas)    │
│  • POST /api/chat-assistant       (Responde dúvidas da Lei 14.133/2021)│
├────────────────────────────────────────────────────────────────────────┤
│  @google/genai SDK (model: gemini-3.8-flash, process.env.GEMINI_API_KEY)│
└────────────────────────────────────────────────────────────────────────┘
```

### Entidades de Dados & Estrutura
- **EditalAnalysis**: `id`, `numeroEdital`, `orgao`, `modalidade`, `criterioJulgamento`, `objeto`, `dataSessao`, `valorEstimado`, `exigenciasHabilitacao` (fiscal, técnica com Cadastur, econômico-financeira), `clausulasRestritivas` (texto, gravidade, baseLegal, sugestaoAcao), `status`.
- **LegalDraft**: `id`, `editalId`, `tipo` (`impugnacao`, `esclarecimento`, `recurso`, `declaracao`, `proposta`), `titulo`, `conteudoFormatado`, `dataGeracao`.
- **CompanyProfile (Levivre Viagens)**: Razão Social, CNPJ, Cadastur, Registro IATA, endereço, responsáveis legais, dados bancários para faturamento público.
- **CertificateItem**: `nome`, `orgaoEmissor`, `linkEmissao`, `nivelSicaf`, `obrigatorio`, `validadeDias`, `status`.

---

## 5. Plano Passo a Passo de Execução

1. **Configuração do Servidor & Proxy Gemini (`server.ts` & Vite Middleware)**:
   - Configurar o servidor Express / middleware Vite para tratar requisições `/api/analyze-edital`, `/api/draft-document`, `/api/chat-assistant` com `@google/genai` e `gemini-3.8-flash`.
   - Adicionar os prompts especialistas calibrados estritamente na Nova Lei de Licitações (Lei 14.133/2021), LC 123/2006 e mercado de turismo/passagens governamentais.
2. **Setup de Tipagem & Dados Especializados para Turismo Governamental**:
   - Criar banco de dados local com certidões oficiais e links reais de emissão (Receita Federal, TST, Caixa, CADASTUR, Fazendas Estaduais).
   - Inserir 3 editais exemplares de agenciamento de viagens para uso e demonstração imediata.
3. **Construção da Interface de Análise de Editais**:
   - Leitor de PDF e texto com arrastar-e-soltar, visualização do Resumo Executivo, Matriz de Riscos de Ilegalidade e Checklist de Habilitação.
4. **Construção do Módulo de Peças Jurídicas & Propostas**:
   - Seletor de peças: Impugnação, Esclarecimento, Recurso, Declarações ME/EPP e Proposta Comercial com taxa de agenciamento.
   - Editor de minuta com destaque para campos editáveis `[ENTRE COLCHETES]` e botões de copiar, baixar e imprimir.
5. **Construção do Radar de Dispensas Eletrônicas e SICAF**:
   - Simulador de propostas rápidas para dispensas do Art. 75, inciso II (viagens e hospedagens de urgência).
   - Painel interativo de certidões e níveis SICAF para a Levivre Viagens.
6. **Construção do Co-piloto Chat Interativo**:
   - Assistente virtual especializado com respostas instantâneas sobre prazos, recursos e estratégias de lance.
7. **Validação e Compilação**:
   - Verificação rigorosa com `compile_applet` e ajustes para garantir zero falhas e alta performance.
